package com.krk.poc.crypto.service;

import org.apache.commons.codec.binary.Hex;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

@Service
public class ARQCService {

    private static final String ALG = "DESede/ECB/NoPadding";
    private final byte[] imkac;

    public ARQCService(@Value("${crypto.imkac}") String hexImkac) throws Exception {
        this.imkac = Hex.decodeHex(hexImkac);
    }

    // Modern: accepts fully concatenated txnDataHex
    public String generateARQC(String txnDataHex) throws Exception {

        System.out.println("txnDataHex: " + txnDataHex);

        byte[] dataBytes = Hex.decodeHex(txnDataHex);
        System.out.println("Raw dataBytes: " + Hex.encodeHexString(dataBytes));
        System.out.println("Raw dataBytes length: " + dataBytes.length);

        dataBytes = padTo8ByteBlock(dataBytes);
        System.out.println("Padded dataBytes: " + Hex.encodeHexString(dataBytes));
        System.out.println("Padded dataBytes length: " + dataBytes.length);

        System.out.println("Original key: " + Hex.encodeHexString(imkac) + " (length: " + imkac.length + ")");

        byte[] key = imkac.length == 16 ? expandTo24(imkac) : imkac;
        System.out.println("Expanded key: " + Hex.encodeHexString(key) + " (length: " + key.length + ")");

        SecretKeySpec keySpec = new SecretKeySpec(key, "DESede");
        Cipher cipher = Cipher.getInstance(ALG);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);

        byte[] cryptogram = cipher.doFinal(dataBytes);
        System.out.println("Cryptogram: " + Hex.encodeHexString(cryptogram));
        System.out.println("Cryptogram length: " + cryptogram.length);

        String arqc = Hex.encodeHexString(sliceFirst8(cryptogram)).toUpperCase();
        System.out.println("ARQC: " + arqc);
        return arqc;

        // System.out.println("txnDataHex: " + txnDataHex);
        // byte[] dataBytes = Hex.decodeHex(txnDataHex);
        // dataBytes = padTo8ByteBlock(dataBytes);

        // byte[] key = imkac.length == 16 ? expandTo24(imkac) : imkac;
        // SecretKeySpec keySpec = new SecretKeySpec(key, "DESede");
        // Cipher cipher = Cipher.getInstance(ALG);
        // cipher.init(Cipher.ENCRYPT_MODE, keySpec);

        // byte[] cryptogram = cipher.doFinal(dataBytes);
        // return Hex.encodeHexString(sliceFirst8(cryptogram)).toUpperCase();
    }

    // Overload for legacy: four arguments, will concatenate for you
    public String generateARQC(String pan, String atc, String unpredictableNumber, String transactionData) throws Exception {
        String txnDataHex = pan + atc + unpredictableNumber + transactionData;
        return generateARQC(txnDataHex);
    }

    // Modern: two-argument version
    public boolean validateARQC(String arqc, String txnDataHex) throws Exception {
        String generated = generateARQC(txnDataHex);
        return generated.equalsIgnoreCase(arqc);
    }

    // Overload for legacy controller
    public boolean validateARQC(String arqc, String pan, String atc, String unpredictableNumber, String transactionData) throws Exception {
        String txnDataHex = pan + atc + unpredictableNumber + transactionData;
        return validateARQC(arqc, txnDataHex);
    }

    private byte[] expandTo24(byte[] key16) {
        byte[] key24 = new byte[24];
        System.arraycopy(key16, 0, key24, 0, 16);
        System.arraycopy(key16, 0, key24, 16, 8);
        return key24;
    }

    private byte[] padTo8ByteBlock(byte[] data) {
        int remainder = data.length % 8;
        if (remainder == 0) return data;
        byte[] padded = new byte[data.length + (8 - remainder)];
        System.arraycopy(data, 0, padded, 0, data.length);
        return padded;
    }

    private byte[] sliceFirst8(byte[] cryptogram) {
        byte[] arqc = new byte[8];
        System.arraycopy(cryptogram, 0, arqc, 0, 8);
        return arqc;
    }
}
